package com.siyal.roomdatabasetwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import data.UserDao;
import data.UserDatabase;
import util.UserRecyclerAdapter;

public class ShowUsersActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UserRecyclerAdapter userRecyclerAdapter;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_users);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        userDao = UserDatabase.getDatabaseInstance(ShowUsersActivity.this).userDao();

        userRecyclerAdapter = new UserRecyclerAdapter(userDao.getAllUsers());

        recyclerView.setLayoutManager(new LinearLayoutManager(ShowUsersActivity.this));
        recyclerView.setAdapter(userRecyclerAdapter);
        userRecyclerAdapter.notifyDataSetChanged();
    }
}
