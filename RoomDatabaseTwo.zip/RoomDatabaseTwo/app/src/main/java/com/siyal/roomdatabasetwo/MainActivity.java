package com.siyal.roomdatabasetwo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import data.UserDao;
import data.UserDatabase;
import model.User;
import util.DataConverter;

public class MainActivity extends AppCompatActivity {

    private Button btnTakePicture;
    private ImageView userImage;
    private EditText txtFullName;
    private EditText txtUsername;
    private EditText txtPassword;
    private EditText txtDob;
    private Button btnSave;
    private Button btnShowUsers;

    public static final int CAMERA_INTENT = 51;
    Bitmap bitmapImage;

    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTakePicture = (Button) findViewById(R.id.btnTakePicture);
        userImage = (ImageView) findViewById(R.id.userImage);
        txtFullName = (EditText) findViewById(R.id.full_name);
        txtUsername = (EditText) findViewById(R.id.user_name);
        txtPassword = (EditText) findViewById(R.id.password);
        txtDob = (EditText) findViewById(R.id.user_dob);
        btnSave = (Button) findViewById(R.id.btnSave);
        btnShowUsers = (Button) findViewById(R.id.btnShowUsers);

        bitmapImage = null;

        userDao = UserDatabase.getDatabaseInstance(MainActivity.this).userDao();          //returns the userDao instance

        btnTakePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUser();
            }
        });

        btnShowUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ShowUsersActivity.class));
            }
        });

    }

    private void takePicture(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(intent.resolveActivity(getPackageManager()) != null ){
            startActivityForResult(intent, CAMERA_INTENT);
        }
    }

    private void saveUser(){
        String fullName = txtFullName.getText().toString();
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();
        String dob = txtDob.getText().toString();

        if(TextUtils.isEmpty(fullName) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(dob) || bitmapImage==null){
            Toast.makeText(MainActivity.this, "Please fill all the fields", Toast.LENGTH_LONG).show();
        }
        else {
            User user = new User();
            user.setFullName(fullName);
            user.setUserName(username);
            user.setPassword(password);
            try {
                user.setDob(new SimpleDateFormat("dd/MM/yyyy").parse(dob));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            user.setImage(DataConverter.convertImageToByteArray(bitmapImage));

            userDao.insertUser(user);
            Toast.makeText(MainActivity.this, "User Saved", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==CAMERA_INTENT && resultCode==RESULT_OK && data!=null){
            bitmapImage =  (Bitmap) data.getExtras().get("data");
            userImage.setImageBitmap(bitmapImage);
        }
    }
}
