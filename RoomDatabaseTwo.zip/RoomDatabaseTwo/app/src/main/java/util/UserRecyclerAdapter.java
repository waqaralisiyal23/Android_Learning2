package util;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.siyal.roomdatabasetwo.R;

import java.util.List;

import model.User;

public class UserRecyclerAdapter extends RecyclerView.Adapter<UserRecyclerAdapter.UserViewHolder> {

    List<User> usersList;

    public UserRecyclerAdapter(List<User> users){
        usersList = users;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item_layout, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = usersList.get(position);
        holder.userImage.setImageBitmap(DataConverter.convertByteArrayToImage(user.getImage()));
        holder.name.setText(user.getFullName());
        holder.dob.setText(user.getDob().toString());
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        ImageView userImage;
        TextView name;
        TextView dob;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            userImage = (ImageView) itemView.findViewById(R.id.card_image);
            name = (TextView) itemView.findViewById(R.id.card_name);
            dob = (TextView) itemView.findViewById(R.id.card_dob);
        }
    }
}
