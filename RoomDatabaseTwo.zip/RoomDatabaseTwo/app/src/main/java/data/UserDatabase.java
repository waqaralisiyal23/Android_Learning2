package data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import model.User;
import util.DataConverter;

@Database(entities = {User.class}, version = 1, exportSchema = false)
@TypeConverters(DataConverter.class)
public abstract class UserDatabase extends RoomDatabase {
    private static UserDatabase userDatabase = null;

    public abstract UserDao userDao();            //returns the Dao object

    public static synchronized UserDatabase getDatabaseInstance(Context context){
        if(userDatabase == null){
            userDatabase = Room.databaseBuilder(context.getApplicationContext(), UserDatabase.class, "userdb")
                    .allowMainThreadQueries()
                    .build();
        }
        return userDatabase;
    }
}
