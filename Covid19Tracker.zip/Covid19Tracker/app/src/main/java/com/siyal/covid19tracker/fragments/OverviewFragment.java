package com.siyal.covid19tracker.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.siyal.covid19tracker.R;

import org.json.JSONException;
import org.json.JSONObject;

public class OverviewFragment extends Fragment {

    private TextView totalCasesText;
    private TextView deathsText;
    private TextView recveredText;
    private TextView currentlyInfectedText;

    private RequestQueue requestQueue;
    private static final String URL = "https://corona.lmao.ninja/v2/all";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_overview, container, false);

        totalCasesText = (TextView) view.findViewById(R.id.total_cases_overall);
        deathsText = (TextView) view.findViewById(R.id.deaths_overall);
        recveredText = (TextView) view.findViewById(R.id.recovered_overall);
        currentlyInfectedText = (TextView) view.findViewById(R.id.currently_infected_cases_overall);

        requestQueue = Volley.newRequestQueue(getContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
//                    JSONObject data = response.getJSONObject("data");
                    totalCasesText.setText(response.getString("cases"));
                    deathsText.setText(response.getString("deaths"));
                    recveredText.setText(response.getString("recovered"));
                    currentlyInfectedText.setText(response.getString("active"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "Error: "+error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(jsonObjectRequest);

        return view;
    }
}
