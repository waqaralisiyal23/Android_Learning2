package com.siyal.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView splashImage;
    private TextView covidTrackerText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        splashImage = (ImageView) findViewById(R.id.splash_image);
        covidTrackerText = (TextView) findViewById(R.id.covid_tracker);

        Animation mAnimation = AnimationUtils.loadAnimation(MainActivity.this, R.anim.splash_transition);
        splashImage.startAnimation(mAnimation);
        covidTrackerText.startAnimation(mAnimation);

        final Intent intent = new Intent(MainActivity.this, BottomNavigationActivity.class);

        Thread timer = new Thread(){
            public void run(){
                try {
                    sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    startActivity(intent);
                    finish();
                }
            }
        };
        timer.start();

    }
}
