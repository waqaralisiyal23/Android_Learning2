package com.siyal.covid19tracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.siyal.covid19tracker.fragments.CountryFragment;
import com.siyal.covid19tracker.fragments.OverviewFragment;
import com.siyal.covid19tracker.fragments.PrecautionsFragment;

public class BottomNavigationActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private Toolbar mToolBar;

    private String title = "Overview";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation);

        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        mToolBar = (Toolbar) findViewById(R.id.main_page_toolbar);

        setSupportActionBar(mToolBar);

        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new OverviewFragment()).commit();
        getSupportActionBar().setTitle(title);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null;

            switch (item.getItemId()){
                case R.id.nav_dashboard:
                    selectedFragment = new OverviewFragment();
                    title = "Overview";
                    break;
                case R.id.nav_country:
                    selectedFragment = new CountryFragment();
                    title = "Countries";
                    break;
                case R.id.nav_precaution:
                    selectedFragment = new PrecautionsFragment();
                    title = "Precautions";
                    break;
            }

            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
            getSupportActionBar().setTitle(title);

            return true;
        }
    };
}
