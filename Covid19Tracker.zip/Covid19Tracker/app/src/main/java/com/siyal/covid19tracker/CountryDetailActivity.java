package com.siyal.covid19tracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.TextView;

import data.CountriesRecyclerAdapter;
import model.Country;

public class CountryDetailActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private TextView countryName;
    private TextView totalCases;
    private TextView todayCases;
    private TextView totalDeaths;
    private TextView todayDeaths;
    private TextView recovered;
    private TextView active;
    private TextView critical;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_detail);

        mToolbar = (Toolbar) findViewById(R.id.country_detail_toolbar);
        countryName = (TextView) findViewById(R.id.country_name_detail);
        totalCases = (TextView) findViewById(R.id.total_cases_detail);
        todayCases = (TextView) findViewById(R.id.today_cases_detail);
        totalDeaths = (TextView) findViewById(R.id.total_deaths_detail);
        todayDeaths = (TextView) findViewById(R.id.today_death_detail);
        recovered = (TextView) findViewById(R.id.total_recovered_detail);
        active = (TextView) findViewById(R.id.active_detail);
        critical = (TextView) findViewById(R.id.critical_detail);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Country Details");

        Country country = (Country) getIntent().getSerializableExtra("userObject");

        countryName.setText(country.getName());
        totalCases.setText(country.getTotalCases());
        todayCases.setText(country.getNewCases());
        totalDeaths.setText(country.getTotalDeaths());
        todayDeaths.setText(country.getNewDeaths());
        recovered.setText(country.getTotalRecovered());
        active.setText(country.getActiveCases());
        critical.setText(country.getCriticalCases());

    }
}
