package com.siyal.covid19tracker.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.siyal.covid19tracker.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import data.CountriesRecyclerAdapter;
import model.Country;

public class CountryFragment extends Fragment {

    private EditText searchField;
    private RecyclerView recyclerView;
    private CountriesRecyclerAdapter countriesRecyclerAdapter;
    private List<Country> countriesList;

    private RequestQueue requestQueue;
    private static final String URL = "https://corona.lmao.ninja/v2/countries?country";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_country, container, false);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        searchField = (EditText) view.findViewById(R.id.search_country);

        requestQueue = Volley.newRequestQueue(getContext());

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        countriesList = new ArrayList<>();

        searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });

        setData();

        return view;
    }

    private void setData() {
        countriesList.clear();
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject countryData = response.getJSONObject(i);
                                Country country = new Country();
                                country.setName(countryData.getString("country"));
                                JSONObject countryInfo = countryData.getJSONObject("countryInfo");
                                country.setFlagLink(countryInfo.getString("flag"));
                                country.setTotalCases(String.valueOf(countryData.getInt("cases")));
                                country.setNewCases(String.valueOf(countryData.getInt("todayCases")));
                                country.setTotalDeaths(String.valueOf(countryData.getInt("deaths")));
                                country.setNewDeaths(String.valueOf(countryData.getInt("todayDeaths")));
                                country.setTotalRecovered(String.valueOf(countryData.getInt("recovered")));
                                country.setActiveCases(String.valueOf(countryData.getInt("active")));
                                country.setCriticalCases(String.valueOf(countryData.getInt("critical")));
                                countriesList.add(country);
                            }
                            countriesRecyclerAdapter = new CountriesRecyclerAdapter(getContext(), countriesList);
                            recyclerView.setAdapter(countriesRecyclerAdapter);
                            countriesRecyclerAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "Error: " + error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(jsonArrayRequest);
    }

    private void filter(String text){
        List<Country> filteredList = new ArrayList<>();

        for (Country country : countriesList){
            if(country.getName().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(country);
            }
        }

        countriesRecyclerAdapter.filterList(filteredList);
    }
}
