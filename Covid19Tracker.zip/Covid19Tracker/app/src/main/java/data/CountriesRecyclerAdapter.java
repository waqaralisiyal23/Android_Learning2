package data;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.siyal.covid19tracker.CountryDetailActivity;
import com.siyal.covid19tracker.R;
import com.squareup.picasso.Picasso;

import java.util.List;

import model.Country;

public class CountriesRecyclerAdapter extends RecyclerView.Adapter<CountriesRecyclerAdapter.CountriesViewholder> {

    private Context context;
    private List<Country> countriesList;

    public CountriesRecyclerAdapter(Context context, List<Country> countriesList) {
        this.context = context;
        this.countriesList = countriesList;
    }

    @NonNull
    @Override
    public CountriesViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row, parent, false);
        return new CountriesViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CountriesViewholder holder, int position) {
        Country country = countriesList.get(position);
        Picasso.get().load(country.getFlagLink()).into(holder.countryFlag);
        holder.totalCases.setText(country.getTotalCases());
        holder.countryName.setText(country.getName());
    }

    @Override
    public int getItemCount() {
        return countriesList.size();
    }

    public void filterList(List<Country> filteredList){
        countriesList = filteredList;
        notifyDataSetChanged();
    }

    public class CountriesViewholder extends RecyclerView.ViewHolder{

        ImageView countryFlag;
        TextView totalCases;
        TextView countryName;

        public CountriesViewholder(@NonNull View itemView) {
            super(itemView);

            countryFlag = (ImageView) itemView.findViewById(R.id.country_flag);
            totalCases = (TextView) itemView.findViewById(R.id.country_total_cases_in_list);
            countryName = (TextView) itemView.findViewById(R.id.country_name_in_list);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, CountryDetailActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("userObject", countriesList.get(getAdapterPosition()));
                    intent.putExtras(bundle);
                    context.startActivity(intent);
                }
            });
        }
    }
}
