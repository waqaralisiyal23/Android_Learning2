package com.siyal.roomdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddNoteActivity extends AppCompatActivity {

    private EditText mNoteEditText;
    private Button btnAdd;

    public static final String NOTE_ADDED = "added_note";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        mNoteEditText = (EditText) findViewById(R.id.add_note_et);
        btnAdd = (Button) findViewById(R.id.add_note_button);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                String note = mNoteEditText.getText().toString();
                if(TextUtils.isEmpty(note)){
                    setResult(RESULT_CANCELED, resultIntent);
                    Toast.makeText(AddNoteActivity.this, "Please Enter a note", Toast.LENGTH_LONG).show();
                }
                else {
                    resultIntent.putExtra(NOTE_ADDED, note);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            }
        });
    }
}
