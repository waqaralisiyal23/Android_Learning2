package com.siyal.roomdemoapp;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.List;
import java.util.UUID;

import model.Note;
import model.NoteViewModel;
import util.NoteListAdapter;

public class MainActivity extends AppCompatActivity implements NoteListAdapter.OnDeleteClickListener {

    private RecyclerView recyclerView;
    private NoteListAdapter noteListAdapter;

    private String TAG = this.getClass().getSimpleName();
    private NoteViewModel noteViewModel;

    public static final int ADD_NOTE_ACTIVITY_REQUEST_CODE = 1;
    public static final int UPDATE_NOTE_ACTIVITY_REQUEST_CODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        noteListAdapter = new NoteListAdapter(MainActivity.this, this);
        recyclerView.setAdapter(noteListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        noteViewModel = ViewModelProviders.of(this).get(NoteViewModel.class);

        noteViewModel.getAllNotes().observe(this, new Observer<List<Note>>() {
            @Override
            public void onChanged(List<Note> notes) {
                noteListAdapter.setNotes(notes);
            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddNoteActivity.class);
                startActivityForResult(intent, ADD_NOTE_ACTIVITY_REQUEST_CODE);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==ADD_NOTE_ACTIVITY_REQUEST_CODE && resultCode==RESULT_OK){
            //Insert Note
            String noteID = UUID.randomUUID().toString();
            Note note = new Note(noteID, data.getStringExtra(AddNoteActivity.NOTE_ADDED));
            noteViewModel.insert(note);

            Toast.makeText(MainActivity.this, "Note Saved", Toast.LENGTH_LONG).show();
        }
        else if (requestCode==UPDATE_NOTE_ACTIVITY_REQUEST_CODE && resultCode==RESULT_OK){
            //Update Note
            Note note = new Note(data.getStringExtra(UpdateNoteActivity.NOTE_ID), data.getStringExtra(UpdateNoteActivity.UPDATED_NOTE));
            noteViewModel.update(note);

            Toast.makeText(MainActivity.this, "Changes Saved", Toast.LENGTH_LONG).show();
        }
        else
            Toast.makeText(MainActivity.this, "Failed to save note", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDeleteClickListener(Note myNote) {
        //Delete Operation
        noteViewModel.delete(myNote);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
