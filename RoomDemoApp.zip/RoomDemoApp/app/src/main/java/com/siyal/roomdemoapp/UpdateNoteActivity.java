package com.siyal.roomdemoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import model.EditNoteViewModel;
import model.Note;

public class UpdateNoteActivity extends AppCompatActivity {

    private EditText updatedNote;
    private Button btnUpdate;
    private Button btnCancel;

    private EditNoteViewModel editNoteViewModel;
    private String noteId;
    private LiveData<Note> note;

    public static final String NOTE_ID = "note_id";
    public static final String UPDATED_NOTE = "note_text";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_note);

        updatedNote = (EditText) findViewById(R.id.updateNoteEt);
        btnUpdate = (Button) findViewById(R.id.btnUpdate);
        btnCancel = (Button) findViewById(R.id.btnCancel);

        noteId = getIntent().getExtras().getString("note_id");

        editNoteViewModel = ViewModelProviders.of(this).get(EditNoteViewModel.class);
        note = editNoteViewModel.getNote(noteId);
        note.observe(this, new Observer<Note>() {
            @Override
            public void onChanged(Note note) {
                updatedNote.setText(note.getNote());
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newNote = updatedNote.getText().toString();
                Intent resultIntent = new Intent();
                if(TextUtils.isEmpty(newNote)){
                    setResult(RESULT_CANCELED, resultIntent);
                    Toast.makeText(UpdateNoteActivity.this, "Please enter first...", Toast.LENGTH_LONG).show();
                }
                else{
                    resultIntent.putExtra(NOTE_ID, noteId);
                    resultIntent.putExtra(UPDATED_NOTE, newNote);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
