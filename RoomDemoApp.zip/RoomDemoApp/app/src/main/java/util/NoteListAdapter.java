package util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.siyal.roomdemoapp.MainActivity;
import com.siyal.roomdemoapp.R;
import com.siyal.roomdemoapp.UpdateNoteActivity;

import java.util.List;

import model.Note;

public class NoteListAdapter extends RecyclerView.Adapter<NoteListAdapter.NoteViewHolder> {

    public interface OnDeleteClickListener{
        void onDeleteClickListener(Note myNote);
    }

    private LayoutInflater layoutInflater;
    private Context context;
    private List<Note> mNotes;

    private OnDeleteClickListener onDeleteClickListener;

    public NoteListAdapter(Context context, OnDeleteClickListener listener) {
        layoutInflater = LayoutInflater.from(context);
        this.context = context;
        onDeleteClickListener = listener;
    }

    public void setNotes(List<Note> notes){
        mNotes = notes;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NoteListAdapter.NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = layoutInflater.inflate(R.layout.list_item, parent, false);
        return new NoteViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteListAdapter.NoteViewHolder holder, int position) {
        if(mNotes!=null){
            Note note = mNotes.get(position);
            holder.setData(note.getNote(), position);
            holder.setListeners();
        }
        else {
            //Covers the case of data not being ready yet
            holder.noteItemView.setText("No Note");
        }
    }

    @Override
    public int getItemCount() {
        return mNotes.size();
    }

    public class NoteViewHolder extends RecyclerView.ViewHolder{

        private TextView noteItemView;
        private ImageView editNote;
        private ImageView deleteNote;
        private int mPosition;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);

            noteItemView = (TextView) itemView.findViewById(R.id.note_text);
            editNote = (ImageView) itemView.findViewById(R.id.editImageView);
            deleteNote = (ImageView) itemView.findViewById(R.id.deleteImageView);
        }

        public  void setData(String note, int position){
            noteItemView.setText(note);
            mPosition = position;
        }

        public void setListeners() {
            editNote.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, UpdateNoteActivity.class);
                    intent.putExtra("note_id", mNotes.get(mPosition).getId());
                    ((Activity)context).startActivityForResult(intent, MainActivity.UPDATE_NOTE_ACTIVITY_REQUEST_CODE);
                }
            });

            deleteNote.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onDeleteClickListener!=null){
                        onDeleteClickListener.onDeleteClickListener(mNotes.get(mPosition));
                    }
                }
            });
        }
    }
}
