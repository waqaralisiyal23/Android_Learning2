package data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import model.Note;

@Database(entities = {Note.class}, version = 1)
public abstract class NoteRoomDatabase extends RoomDatabase {

    public abstract NoteDao noteDao();

    //creating singelton object
    private static volatile NoteRoomDatabase noteRoomInstance;

    public static NoteRoomDatabase getDatabase(Context context){
        if(noteRoomInstance == null){
            synchronized (NoteRoomDatabase.class){
                noteRoomInstance = Room.databaseBuilder(context.getApplicationContext(), NoteRoomDatabase.class, "note_database").build();
            }
        }
        return noteRoomInstance;
    }

}
