package model;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import data.NoteDao;
import data.NoteRoomDatabase;

public class EditNoteViewModel extends AndroidViewModel {

    private NoteDao noteDao;
    private NoteRoomDatabase db;

    private String TAG = this.getClass().getSimpleName();

    public EditNoteViewModel(@NonNull Application application) {
        super(application);

        db = NoteRoomDatabase.getDatabase(application);
        noteDao = db.noteDao();
    }

    public LiveData<Note> getNote(String noteId){
        return noteDao.getNote(noteId);
    }
}
